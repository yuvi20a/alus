<footer>
    <p>&copy; <?=date('Y')?> Buah-Buahan Baper</p>
</footer>
</body>
</html>

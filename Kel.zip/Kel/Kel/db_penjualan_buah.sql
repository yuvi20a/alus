--
-- Struktur tabel untuk tabel `buah`
--
CREATE TABLE IF NOT EXISTS `buah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `deskripsi` text,
  `harga` int(11) NOT NULL,
  `gambar` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Contoh data awal
--
INSERT INTO `buah` (`nama`, `deskripsi`, `harga`, `gambar`) VALUES
('Apel Fuji', 'Apel segar dari Jepang, manis dan renyah.', 25000, 'apel.jpg'),
('Jeruk Sunkist', 'Jeruk impor dengan rasa segar dan kaya vitamin C.', 18000, 'jeruk.jpg'),
('Pisang Cavendish', 'Pisang kuning, cocok untuk sarapan.', 12000, 'pisang.jpg'),
('Mangga Harum Manis', 'Mangga lokal dengan aroma harum dan rasa manis.', 22000, 'mangga.jpg');

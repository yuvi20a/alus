<?php
session_start();
require_once 'koneksi.php';
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
if (!($_SESSION['is_admin'] ?? 0)) {
    echo "Akses ditolak.";
    exit;
}
$errors = [];
// Tambah buah
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['tambah'])) {
    $nama = trim($_POST['nama'] ?? '');
    $deskripsi = trim($_POST['deskripsi'] ?? '');
    $harga = intval($_POST['harga'] ?? 0);
    $stok = intval($_POST['stok'] ?? 0);
    $gambar = 'placeholder.png';
    if (isset($_FILES['gambar']) && $_FILES['gambar']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif','webp'];
        if (in_array($ext, $allowed)) {
            $newName = uniqid('buah_', true) . '.' . $ext;
            if (!is_dir('images')) mkdir('images');
            move_uploaded_file($_FILES['gambar']['tmp_name'], 'images/' . $newName);
            $gambar = $newName;
        } else {
            $errors[] = "Format gambar tidak didukung.";
        }
    } else if (!empty($_POST['gambar_text'])) {
        $gambar = $_POST['gambar_text'];
    }
    if (!$nama || !$harga) {
        $errors[] = "Nama dan harga wajib diisi.";
    } else if (empty($errors)) {
        $stmt = $pdo->prepare("INSERT INTO buah (nama, deskripsi, harga, gambar, stok) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nama, $deskripsi, $harga, $gambar, $stok]);
    }
}
// Hapus buah
if (isset($_GET['hapus'])) {
    $id = intval($_GET['hapus']);
    $pdo->prepare("DELETE FROM buah WHERE id = ?")->execute([$id]);
}
// Ambil data buah
$stmt = $pdo->query("SELECT * FROM buah");
$buah = $stmt->fetchAll();

// Ambil data pembelian (laporan)
$stmt = $pdo->query("SELECT p.*, u.username FROM pembelian p LEFT JOIN users u ON p.user_id = u.id ORDER BY p.tanggal DESC");
$laporan = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - Buah-Buahan Baper</title>
    <link rel="stylesheet" href="index.css">
    <style>
        body {
            /* Ensure background covers admin page fully */
            min-height: 100vh;
        }
        .admin-container {
            max-width: 900px;
            margin: 48px auto;
            background: rgba(255,255,255,0.85);
            border-radius: 32px;
            box-shadow: 0 8px 40px 0 rgba(255, 180, 80, 0.18), 0 1.5px 0 #fffbe6;
            padding: 40px 36px 36px 36px;
            backdrop-filter: blur(2.5px);
        }
        .admin-container h2 {
            text-align: center;
            color: #ff4e50;
            margin-bottom: 28px;
            letter-spacing: 1px;
            font-size: 2.1em;
            font-weight: 800;
            text-shadow: 0 2px 12px #fff7e6, 0 0 0 #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }
        .admin-container h2::before {
            content: '\1F34E'; /* emoji apel merah */
            font-size: 1.1em;
            margin-right: 6px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 22px;
            background: rgba(255,251,230,0.92);
            border-radius: 18px;
            overflow: hidden;
            box-shadow: 0 2px 12px #f9d42333;
        }
        th, td {
            padding: 13px 10px;
            border-bottom: 1px solid #ffe7c7;
            text-align: center;
        }
        th {
            background: linear-gradient(90deg, #ff4e50 0%, #f9d423 100%);
            color: #fff;
            font-weight: 700;
            letter-spacing: 0.5px;
        }
        .admin-container form {
            margin-bottom: 24px;
        }
        .admin-container label {
            display: block;
            margin-bottom: 8px;
            color: #ff4e50;
            font-weight: 600;
        }
        .admin-container input, .admin-container textarea {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #f9d423;
            margin-bottom: 12px;
            font-size: 1.05em;
            background: rgba(255,251,230,0.92);
            color: #ff4e50;
        }
        .admin-container button {
            background: linear-gradient(90deg, #ff4e50 0%, #f9d423 100%);
            color: #fff;
            border: none;
            padding: 12px 0;
            border-radius: 12px;
            font-size: 1.08em;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: background 0.2s, transform 0.1s;
            box-shadow: 0 2px 8px #ffe0c3;
        }
        .admin-container button:hover {
            background: linear-gradient(90deg, #f9d423 0%, #ff4e50 100%);
            transform: scale(1.04);
        }
        .admin-container ul {
            padding-left: 20px;
            margin-bottom: 18px;
        }
        .admin-container ul li {
            color: #e74c3c;
            font-size: 0.98em;
        }
        a {
            color: #ff4e50;
            text-decoration: none;
            font-weight: 600;
            transition: color 0.18s;
        }
        a:hover {
            text-decoration: underline;
            color: #f9d423;
        }
        /* Logout button style harmonized with theme */
        .admin-container > div > a {
            color: #fff !important;
            background: linear-gradient(90deg, #ff4e50 0%, #f9d423 100%);
            padding: 7px 16px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            box-shadow: 0 2px 8px #ffe0c3;
            border: none;
            transition: background 0.2s, color 0.2s;
        }
        .admin-container > div > a:hover {
            background: linear-gradient(90deg, #f9d423 0%, #ff4e50 100%);
            color: #fff !important;
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <div style="display:flex; justify-content: flex-end; margin-bottom: 10px;">
            <a href="index.php" style="color:#fff; background:#e74c3c; padding:7px 16px; border-radius:6px; text-decoration:none; font-weight:bold;">Logout</a>
        </div>
        <h2>Dashboard Admin</h2>
        <?php if ($errors): ?>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?=htmlspecialchars($error)?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        <form method="post" enctype="multipart/form-data" id="form-buah">
            <label>Nama Buah:
                <input type="text" name="nama" required>
            </label>
            <label>Manfaat  :
                <textarea name="deskripsi"></textarea>
            </label>
            <label>Harga:
                <input type="number" name="harga" required>
            </label>
            <label>Stok:
                <input type="number" name="stok" min="0" required>
            </label>
            <label>Upload Gambar:
                <input type="file" name="gambar" accept="image/*" id="input-gambar">
            </label>
            <label>Atau Nama File Gambar (opsional):
                <input type="text" name="gambar_text" placeholder="Misal: apel.jpg" id="input-gambar-text">
            </label>
            <div style="text-align:center;margin-bottom:14px;">
                <img id="preview-gambar" src="images/placeholder.png" alt="Preview Gambar" style="max-width:120px;max-height:120px;border-radius:10px;border:1px solid #eee;display:inline-block;">
            </div>
            <button type="submit" name="tambah">Tambah Buah</button>
        </form>
        <table>
            <tr>
                <th>ID</th>
                <th>Nama</th>
                <th>Deskripsi</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Gambar</th>
                <th>Aksi</th>
            </tr>
            <?php foreach ($buah as $b): ?>
                <tr>
                    <td><?=$b['id']?></td>
                    <td><?=htmlspecialchars($b['nama'])?></td>
                    <td><?=htmlspecialchars($b['deskripsi'])?></td>
                    <td>Rp <?=number_format($b['harga'],0,',','.')?></td>
                    <td><?=isset($b['stok']) ? (int)$b['stok'] : 0?></td>
                    <td>
                        <?php if (!empty($b['gambar'])): ?>
                            <img src="images/<?=htmlspecialchars($b['gambar'])?>" alt="Gambar" style="max-width:60px;max-height:60px;border-radius:8px;border:1px solid #eee;">
                        <?php else: ?>
                            <img src="images/placeholder.png" alt="Gambar" style="max-width:60px;max-height:60px;border-radius:8px;border:1px solid #eee;">
                        <?php endif; ?>
                        <div style="font-size:0.85em;color:#888;word-break:break-all;">
                            <?=htmlspecialchars($b['gambar'])?>
                        </div>
                    </td>
                    <td>
                        <a href="edit_buah.php?id=<?=$b['id']?>" style="color:#2980b9; margin-right:8px; font-weight:bold;">Edit</a>
                        <a href="?hapus=<?=$b['id']?>" onclick="return confirm('Hapus buah ini?')" style="color:#e74c3c; font-weight:bold;">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
        <div style="margin-top:38px;">
            <h2 style="font-size:1.4em; color:#27ae60; margin-bottom:18px;">Laporan Pembelian</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Tanggal</th>
                    <th>Total</th>
                    <th>Metode</th>
                    <th>Aksi</th>
                </tr>
                <?php
                function labelMetode($kode) {
                    $map = [
                        'transfer_bca' => 'Transfer BCA',
                        'transfer_bri' => 'Transfer BRI',
                        'transfer_bni' => 'Transfer BNI',
                        'cod' => 'Bayar di Tempat',
                        'qris' => 'QRIS',
                        'gopay' => 'GoPay',
                        'ovo' => 'OVO',
                        'dana' => 'DANA',
                        'shopeepay' => 'ShopeePay',
                    ];
                    return $map[$kode] ?? ucfirst(str_replace('_',' ',$kode));
                }
                foreach ($laporan as $row): ?>
                <tr>
                    <td><?= $row['id'] ?></td>
                    <td><?= htmlspecialchars($row['username'] ?: '-') ?></td>
                    <td><?= date('d-m-Y H:i', strtotime($row['tanggal'])) ?></td>
                    <td>Rp <?= number_format($row['total'],0,',','.') ?></td>
                    <td><?= isset($row['metode_pembayaran']) && $row['metode_pembayaran'] ? labelMetode($row['metode_pembayaran']) : '-' ?></td>
                    <td><a href="cetak_struk.php?id=<?= $row['id'] ?>" target="_blank">Cetak Struk</a></td>
                </tr>
                <?php endforeach; ?>
            </table>
        </div>
        <div style="text-align:center;margin-top:18px;">
            <a href="index.php">&larr; Kembali ke Beranda</a>
        </div>
    <script>
    // Preview gambar saat upload file
    const inputGambar = document.getElementById('input-gambar');
    const inputGambarText = document.getElementById('input-gambar-text');
    const previewGambar = document.getElementById('preview-gambar');
    inputGambar.addEventListener('change', function(e) {
        if (this.files && this.files[0]) {
            const reader = new FileReader();
            reader.onload = function(ev) {
                previewGambar.src = ev.target.result;
            };
            reader.readAsDataURL(this.files[0]);
        }
    });
    inputGambarText.addEventListener('input', function(e) {
        if (this.value.trim() !== '') {
            previewGambar.src = 'images/' + this.value.trim();
        } else {
            previewGambar.src = 'images/placeholder.png';
        }
    });
    </script>
    </div>
</body>
</html>

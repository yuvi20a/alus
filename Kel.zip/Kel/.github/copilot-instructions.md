# Copilot Instructions for Buah-Buahan Baper

## Project Overview
- This is a PHP & MySQL web application for a modern fruit shop ("Buah-Buahan Baper").
- Key features: product listing, cart, checkout, user registration/login, and an admin dashboard for CRUD operations.
- The UI is styled with external CSS (see `index.css` and/or `style.css`).

## Architecture & File Structure
- Flat PHP file structure (no framework): each page is a separate PHP file (e.g., `index.php`, `keranjang.php`, `admin.php`, `login.php`, etc).
- Database connection is handled via `koneksi.php` (PDO, MySQL).
- Session variables are used for authentication, cart, and admin/user role separation.
- SQL schema files: `db_penjualan_buah.sql`, `db_penjualan_buah_full.sql`, `users.sql`, `pembelian.sql`.
- Images and static assets are stored in the root or referenced by relative path.

## Key Patterns & Conventions
- All user-facing logic is in PHP files; no MVC separation.
- Admin and user logic is separated by `$_SESSION['is_admin']` checks in each relevant file.
- Cart and checkout logic is in `keranjang.php`, with payment method and transaction logic handled via POST and session state.
- Admin dashboard (`admin.php`) provides CRUD for fruits and purchase reports.
- CSS backgrounds: background images are set via CSS using the correct filename and extension (e.g., `background buah.jpg`).
- All pages should include the same CSS file for consistent theming.

## Developer Workflow
- To run locally: use XAMPP or similar, place files in `htdocs`, import the provided SQL, and access via browser.
- No build step; just reload browser after edits.
- Debugging: use `var_dump`, `die`, or browser dev tools for HTML/CSS issues.
- Database changes: update SQL files and re-import as needed.

## Examples
- To add a new page, copy an existing PHP file and adjust logic as needed.
- To add a new field to a table, update the SQL and adjust relevant PHP queries.
- To restrict admin/user actions, use `if ($_SESSION['is_admin'])` blocks.

## Integration Points
- No external APIs; all logic is local PHP and MySQL.
- Images referenced in CSS must match the actual filename and extension.

## Important Files
- `index.php`, `keranjang.php`, `admin.php`, `koneksi.php`, `index.css`, `style.css`, `db_penjualan_buah.sql`

---
If you add new features, follow the flat PHP file pattern and update the README and this file as needed.
